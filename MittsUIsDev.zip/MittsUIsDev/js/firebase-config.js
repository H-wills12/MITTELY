// Firebase configuration - Replace with your actual config
const firebaseConfig = {
    apiKey: "AIzaSyCH1FXHoFtLHXTHGfuWtKtx8A1aiYD5rzY",
    authDomain: "mitts-uis.firebaseapp.com",
    projectId: "mitts-uis",
    storageBucket: "mitts-uis.firebasestorage.app",
    messagingSenderId: "999743125008",
    appId: "1:999743125008:web:e0428b6c864cba436b3c95"
};

// Assign to global variable to be used in app.js
window.firebaseConfig = firebaseConfig;